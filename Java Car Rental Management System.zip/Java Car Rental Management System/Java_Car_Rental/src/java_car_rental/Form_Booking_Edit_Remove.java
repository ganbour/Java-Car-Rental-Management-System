/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_car_rental;

import Classes.Brand;
import Classes.Car;
import Classes.Location;
import Classes.Booking;
import Classes.Customer;
import java.awt.Color;
import java.awt.Image;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.border.Border;


/**
 *
 * @author 1BestCsharp
 */
public class Form_Booking_Edit_Remove extends javax.swing.JFrame {

    /**
     * Creates new form Form_Booking_Edit_Remove
     */
    
    Border border = BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(0,0,153));
    Border panel_border = BorderFactory.createMatteBorder(1, 1, 1, 1, Color.darkGray);
    Brand brand = new Brand();
    Car car = new Car();
    Location location = new Location();
    Booking booking = new Booking();
    HashMap<Integer, String> map = brand.brandsHashMap();
    
    public Form_Booking_Edit_Remove() {
        initComponents();

        // center the form
        this.setLocationRelativeTo(null);
        
        // set border
        jLabel_select_car.setBorder(border);
        jLabel_select_customer.setBorder(border);
        jLabel_pickup.setBorder(border);
        jLabel_dropoff.setBorder(border);
        
        jPanel_select_customer.setBorder(panel_border);
        jPanel_select_car.setBorder(panel_border);
        jPanel_pickup.setBorder(panel_border);
        jPanel_dropoff.setBorder(panel_border);
        
        populateComboboxBrands();
        
        
        displayImage(jLabel_BookCar_logo.getWidth(), jLabel_BookCar_logo.getHeight(), getClass().getResource("images/calendar_1.png").getFile(), jLabel_BookCar_logo);
   
    }
    
    // create a function to resize the image so it can fit the jlabel
    public void displayImage(int width, int height, String image_path, JLabel label)
    {
        // get the image
        ImageIcon imageIco = new ImageIcon(image_path);
        // resize the image
        Image image = imageIco.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        // set the image into the jlabel
        label.setIcon(new ImageIcon(image));
    }
    
    
    
        // create a static function to sisplay customer id and name
    public static void displayCustomer(String id, String name)
    {
        jTextField_customer.setText(name);
        jLabel_customer_id.setText(id);
    }
    
    // create a static function to sisplay customer id and name
    public static void displayCarInfo(String id, String model, String price)
    {
        jLabel_car_id.setText(id);
        jLabel_car_model.setText(model);
        jLabel_car_price.setText(price);
    }
    
    
    // create a static function to sisplay customer id and name
    public static void displayBooking(String id, String car_id,String customer_id, String pickup_city,
                                      String pickup_address, String pickup_date, String pickup_time, 
                                      String dropoff_city, String dropoff_address,String dropoff_date, 
                                      String dropoff_time, String total_price)
    {
        /*
        id, car_id, customer_id, pickup_city, pickup_address, pickup_date,
        pickup_time, dropoff_city, dropoff_address, dropoff_date, dropoff_time,
        total_price
        */
        jTextField_customer.setText(new Customer().getCustomerById(Integer.valueOf(customer_id)).getFullname());
        jLabel_booking_id.setText(id);
        jLabel_car_id.setText(car_id);
        
        jLabel_car_model.setText(new Car().getCarById(Integer.valueOf(car_id)).getModel());
        jLabel_car_price.setText(String.valueOf(new Car().getCarById(Integer.valueOf(car_id)).getPrice()));
        jLabel_brand_id.setText(String.valueOf(new Car().getCarById(Integer.valueOf(car_id)).getBrand()));
        
       jComboBox_Brands_.setSelectedItem(new Brand().getBrandById(new Car().getCarById(Integer.valueOf(car_id)).getBrand()).getName());
        
        jLabel_customer_id.setText(customer_id);
        jLabel_total_price.setText(total_price);
        
        jComboBox_Pickup_City.setSelectedItem(pickup_city);
        jComboBox_Pickup_Address.setSelectedItem(pickup_address);
        jComboBox_Dropoff_City.setSelectedItem(dropoff_city);
        jComboBox_Dropoff_Address.setSelectedItem(dropoff_address);
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        
        try {
            jDateChooser_Pickup_Date.setDate(dateFormat.parse(pickup_date));
            jDateChooser__Dropoff_Date.setDate(dateFormat.parse(dropoff_date));
            
            timePicker_Pickup_Time.setText(pickup_time);
            timePicker_Dropoff_Time.setText(dropoff_time);
            
        } catch (ParseException ex) {
            Logger.getLogger(Form_Booking_Edit_Remove.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
    
    
    // create a function to populate the jcombobox_address with addresses
    // and to do that we will use a hashmap
    public void populateComboboxAddresses(String pickup_or_dropoff,String city)
    {
        if(pickup_or_dropoff.equals("pickup"))
        {
            // clear combobox
            jComboBox_Pickup_Address.removeAllItems();
            // populate combobox
            for(Location l : location.locationsListByCity(city))
            {
              jComboBox_Pickup_Address.addItem(l.getAddress());
            }
        }
        else if(pickup_or_dropoff.equals("dropoff"))
        {
            // clear combobox
            jComboBox_Dropoff_Address.removeAllItems();
            // populate combobox
            for(Location l : location.locationsListByCity(city))
            {
              jComboBox_Dropoff_Address.addItem(l.getAddress());
            }
        }
        
    }
    
    // create a function to populate the jcombobox_address with addresses
    // create a function to populate the jcombobox_brands with brands
    // and to do that we will use a hashmap
    public void populateComboboxBrands()
    {
        for(String s : map.values())
        {
            jComboBox_Brands_.addItem(s);
        }
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel_BookCar_logo = new javax.swing.JLabel();
        jLabel_close = new javax.swing.JLabel();
        jLabel_imagePath = new javax.swing.JLabel();
        jPanel_select_car = new javax.swing.JPanel();
        jLabel_select_car = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jComboBox_Brands_ = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel_brand_id = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel_car_id = new javax.swing.JLabel();
        jButton_select_car_ = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel_car_model = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel_car_price = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jPanel_select_customer = new javax.swing.JPanel();
        jLabel_select_customer = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jTextField_customer = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel_customer_id = new javax.swing.JLabel();
        jButton_select_customer_ = new javax.swing.JButton();
        jPanel_pickup = new javax.swing.JPanel();
        jLabel_pickup = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jComboBox_Pickup_City = new javax.swing.JComboBox<>();
        jComboBox_Pickup_Address = new javax.swing.JComboBox<>();
        jDateChooser_Pickup_Date = new com.toedter.calendar.JDateChooser();
        timePicker_Pickup_Time = new com.github.lgooddatepicker.components.TimePicker();
        jPanel_dropoff = new javax.swing.JPanel();
        jLabel_dropoff = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jComboBox_Dropoff_City = new javax.swing.JComboBox<>();
        jComboBox_Dropoff_Address = new javax.swing.JComboBox<>();
        jDateChooser__Dropoff_Date = new com.toedter.calendar.JDateChooser();
        timePicker_Dropoff_Time = new com.github.lgooddatepicker.components.TimePicker();
        jButton_EditBooking_ = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel_price_text = new javax.swing.JLabel();
        jLabel_total_price = new javax.swing.JLabel();
        jButton_calculate_ = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel_price_text1 = new javax.swing.JLabel();
        jLabel_booking_id = new javax.swing.JLabel();
        jButton_BookingList_ = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        jButton_RemoveBooking_ = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jPanel3.setBackground(new java.awt.Color(61, 61, 61));
        jPanel3.setPreferredSize(new java.awt.Dimension(624, 75));

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Booking Edit / Remove");
        jLabel4.setFont(new java.awt.Font("Verdana", 0, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));

        jLabel_close.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel_close.setForeground(new java.awt.Color(255, 255, 255));
        jLabel_close.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_close.setText("X");
        jLabel_close.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_closeMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel_BookCar_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(240, 240, 240)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel_close, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(319, 319, 319))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel_BookCar_logo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 53, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel_close)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jLabel_imagePath.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_imagePath.setText("     ");
        jLabel_imagePath.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel_select_car.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_select_car.setText("Select a Car");
        jLabel_select_car.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel_select_car.setForeground(new java.awt.Color(0, 0, 153));

        jLabel2.setText("Brand:");
        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel3.setText("Car:");
        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jComboBox_Brands_.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jComboBox_Brands_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_Brands_ActionPerformed(evt);
            }
        });

        jLabel5.setText("ID:");
        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel_brand_id.setText("000");
        jLabel_brand_id.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel7.setText("ID:");
        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel_car_id.setText("000");
        jLabel_car_id.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jButton_select_car_.setText("Select Car");
        jButton_select_car_.setBackground(new java.awt.Color(44, 62, 80));
        jButton_select_car_.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton_select_car_.setForeground(new java.awt.Color(255, 255, 255));
        jButton_select_car_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_select_car_ActionPerformed(evt);
            }
        });

        jLabel12.setText("Model:");
        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel_car_model.setText("###");
        jLabel_car_model.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel17.setText("Price:");
        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel_car_price.setText("000");
        jLabel_car_price.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel18.setText("|");
        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 102, 0));

        javax.swing.GroupLayout jPanel_select_carLayout = new javax.swing.GroupLayout(jPanel_select_car);
        jPanel_select_car.setLayout(jPanel_select_carLayout);
        jPanel_select_carLayout.setHorizontalGroup(
            jPanel_select_carLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel_select_car, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel_select_carLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel_select_carLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel_select_carLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel_select_carLayout.createSequentialGroup()
                        .addComponent(jComboBox_Brands_, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel_brand_id)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel_select_carLayout.createSequentialGroup()
                        .addComponent(jButton_select_car_, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel_select_carLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel_select_carLayout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel_car_model, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel_select_carLayout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel_car_id)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel18)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel17)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel_car_price)))
                        .addGap(0, 30, Short.MAX_VALUE))))
        );
        jPanel_select_carLayout.setVerticalGroup(
            jPanel_select_carLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_select_carLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel_select_car)
                .addGap(28, 28, 28)
                .addGroup(jPanel_select_carLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jComboBox_Brands_, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel_brand_id))
                .addGap(18, 18, 18)
                .addGroup(jPanel_select_carLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jButton_select_car_)
                    .addComponent(jLabel7)
                    .addComponent(jLabel_car_id)
                    .addComponent(jLabel17)
                    .addComponent(jLabel_car_price)
                    .addComponent(jLabel18))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel_select_carLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(jLabel_car_model))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel_select_customer.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_select_customer.setText("Select Customer");
        jLabel_select_customer.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel_select_customer.setForeground(new java.awt.Color(0, 0, 153));

        jLabel6.setText("Customer:");
        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jTextField_customer.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel1.setText("ID:");
        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel_customer_id.setText("000");
        jLabel_customer_id.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jButton_select_customer_.setText("Select Customer");
        jButton_select_customer_.setBackground(new java.awt.Color(44, 62, 80));
        jButton_select_customer_.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jButton_select_customer_.setForeground(new java.awt.Color(255, 255, 255));
        jButton_select_customer_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_select_customer_ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel_select_customerLayout = new javax.swing.GroupLayout(jPanel_select_customer);
        jPanel_select_customer.setLayout(jPanel_select_customerLayout);
        jPanel_select_customerLayout.setHorizontalGroup(
            jPanel_select_customerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel_select_customer, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel_select_customerLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel_select_customerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel_select_customerLayout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel_customer_id)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel_select_customerLayout.createSequentialGroup()
                        .addComponent(jTextField_customer, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton_select_customer_, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(23, 23, 23))))
        );
        jPanel_select_customerLayout.setVerticalGroup(
            jPanel_select_customerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_select_customerLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel_select_customer)
                .addGap(30, 30, 30)
                .addGroup(jPanel_select_customerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_select_customerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel6)
                        .addComponent(jTextField_customer, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton_select_customer_, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel_select_customerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel_customer_id))
                .addContainerGap())
        );

        jLabel_pickup.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_pickup.setText("Pick Up Location & Date");
        jLabel_pickup.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel_pickup.setForeground(new java.awt.Color(0, 0, 153));

        jLabel8.setText("City:");
        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel9.setText("Address:");
        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel10.setText("Time:");
        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel11.setText("Date:");
        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jComboBox_Pickup_City.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "City 1", "City 2", "City 3", "City 4" }));
        jComboBox_Pickup_City.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_Pickup_CityActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel_pickupLayout = new javax.swing.GroupLayout(jPanel_pickup);
        jPanel_pickup.setLayout(jPanel_pickupLayout);
        jPanel_pickupLayout.setHorizontalGroup(
            jPanel_pickupLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel_pickup, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel_pickupLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel_pickupLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel_pickupLayout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(41, 41, 41)
                        .addComponent(jComboBox_Pickup_City, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel_pickupLayout.createSequentialGroup()
                        .addGroup(jPanel_pickupLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(jLabel11)
                            .addComponent(jLabel10))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel_pickupLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jComboBox_Pickup_Address, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jDateChooser_Pickup_Date, javax.swing.GroupLayout.DEFAULT_SIZE, 286, Short.MAX_VALUE)
                            .addComponent(timePicker_Pickup_Time, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(51, Short.MAX_VALUE))
        );
        jPanel_pickupLayout.setVerticalGroup(
            jPanel_pickupLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_pickupLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel_pickup)
                .addGap(27, 27, 27)
                .addGroup(jPanel_pickupLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jComboBox_Pickup_City, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel_pickupLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jComboBox_Pickup_Address, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addGroup(jPanel_pickupLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addComponent(jDateChooser_Pickup_Date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel_pickupLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(timePicker_Pickup_Time, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jLabel_dropoff.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_dropoff.setText("Drop Off Location & Date");
        jLabel_dropoff.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel_dropoff.setForeground(new java.awt.Color(0, 0, 153));

        jLabel13.setText("City:");
        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel14.setText("Address:");
        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel15.setText("Time:");
        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel16.setText("Date:");
        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jComboBox_Dropoff_City.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "City 1", "City 2", "City 3", "City 4" }));
        jComboBox_Dropoff_City.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_Dropoff_CityActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel_dropoffLayout = new javax.swing.GroupLayout(jPanel_dropoff);
        jPanel_dropoff.setLayout(jPanel_dropoffLayout);
        jPanel_dropoffLayout.setHorizontalGroup(
            jPanel_dropoffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel_dropoff, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel_dropoffLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel_dropoffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel_dropoffLayout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addGap(41, 41, 41)
                        .addComponent(jComboBox_Dropoff_City, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel_dropoffLayout.createSequentialGroup()
                        .addGroup(jPanel_dropoffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14)
                            .addComponent(jLabel16)
                            .addComponent(jLabel15))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel_dropoffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jComboBox_Dropoff_Address, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jDateChooser__Dropoff_Date, javax.swing.GroupLayout.DEFAULT_SIZE, 286, Short.MAX_VALUE)
                            .addComponent(timePicker_Dropoff_Time, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(51, Short.MAX_VALUE))
        );
        jPanel_dropoffLayout.setVerticalGroup(
            jPanel_dropoffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_dropoffLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel_dropoff)
                .addGap(27, 27, 27)
                .addGroup(jPanel_dropoffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(jComboBox_Dropoff_City, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel_dropoffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(jComboBox_Dropoff_Address, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addGroup(jPanel_dropoffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel16)
                    .addComponent(jDateChooser__Dropoff_Date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel_dropoffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15)
                    .addComponent(timePicker_Dropoff_Time, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jButton_EditBooking_.setText("Edit Booking");
        jButton_EditBooking_.setBackground(new java.awt.Color(41, 128, 185));
        jButton_EditBooking_.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton_EditBooking_.setForeground(new java.awt.Color(255, 255, 255));
        jButton_EditBooking_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_EditBooking_ActionPerformed(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(153, 153, 153));

        jLabel_price_text.setText("Total Price:");
        jLabel_price_text.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel_total_price.setText("0000");
        jLabel_total_price.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jButton_calculate_.setText("calculate");
        jButton_calculate_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_calculate_ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel_price_text)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel_total_price, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton_calculate_)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel_price_text)
                    .addComponent(jLabel_total_price))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton_calculate_)
                .addContainerGap())
        );

        jPanel5.setBackground(new java.awt.Color(204, 204, 204));

        jLabel_price_text1.setText("Select Booking:");
        jLabel_price_text1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel_booking_id.setText("00");
        jLabel_booking_id.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jButton_BookingList_.setText("Booking List");
        jButton_BookingList_.setBackground(new java.awt.Color(44, 62, 80));
        jButton_BookingList_.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton_BookingList_.setForeground(new java.awt.Color(255, 255, 255));
        jButton_BookingList_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_BookingList_ActionPerformed(evt);
            }
        });

        jLabel19.setText("ID:");
        jLabel19.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jLabel_price_text1)
                .addGap(17, 17, 17)
                .addComponent(jButton_BookingList_, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel19)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel_booking_id, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel_booking_id)
                    .addComponent(jLabel_price_text1)
                    .addComponent(jButton_BookingList_, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jButton_RemoveBooking_.setText("Reomve / Cancel Booking");
        jButton_RemoveBooking_.setBackground(new java.awt.Color(192, 57, 43));
        jButton_RemoveBooking_.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton_RemoveBooking_.setForeground(new java.awt.Color(255, 255, 255));
        jButton_RemoveBooking_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_RemoveBooking_ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 1377, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel_select_car, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel_select_customer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(63, 63, 63)
                        .addComponent(jButton_RemoveBooking_, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton_EditBooking_, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(49, 49, 49)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel_dropoff, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel_pickup, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel_imagePath, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel_pickup, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(106, 106, 106)
                                .addComponent(jLabel_imagePath, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel_dropoff, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel_select_car, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel_select_customer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton_EditBooking_, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton_RemoveBooking_, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 1061, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel_closeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_closeMouseClicked
        // close the form
        this.dispose();
    }//GEN-LAST:event_jLabel_closeMouseClicked

    private void jComboBox_Brands_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_Brands_ActionPerformed
        // get the selected brand id
        int brand_id = 0;
        for(Map.Entry<Integer, String> entry : map.entrySet())
        {
            if(entry.getValue().equals(jComboBox_Brands_.getSelectedItem().toString()))
            {
                brand_id = entry.getKey();
            }
        }
        jLabel_brand_id.setText(String.valueOf(brand_id));
    }//GEN-LAST:event_jComboBox_Brands_ActionPerformed

    private void jButton_select_car_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_select_car_ActionPerformed

        // get the brand id
        int brand_id = Integer.valueOf(jLabel_brand_id.getText());

        // show the cars list form
        Form_CarsListByBrand frm_cars_brand = new Form_CarsListByBrand(brand_id,"edit");
        frm_cars_brand.setVisible(true);
    }//GEN-LAST:event_jButton_select_car_ActionPerformed

    private void jButton_select_customer_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_select_customer_ActionPerformed
        // show the customers list
        Form_CustomersList frm_cst_list = new Form_CustomersList("edit");
        frm_cst_list.setVisible(true);

    }//GEN-LAST:event_jButton_select_customer_ActionPerformed

    private void jComboBox_Pickup_CityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_Pickup_CityActionPerformed
        // populate jcombobox address depending on the city combobox
        populateComboboxAddresses("pickup", jComboBox_Pickup_City.getSelectedItem().toString());

    }//GEN-LAST:event_jComboBox_Pickup_CityActionPerformed

    private void jComboBox_Dropoff_CityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_Dropoff_CityActionPerformed
        // populate jcombobox address depending on the city combobox
        populateComboboxAddresses("dropoff", jComboBox_Dropoff_City.getSelectedItem().toString());

    }//GEN-LAST:event_jComboBox_Dropoff_CityActionPerformed

    private void jButton_EditBooking_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_EditBooking_ActionPerformed
        // edit booking

        try{
            // booking id
            int id = Integer.valueOf(jLabel_booking_id.getText());
            // get the car info
            int car_id = Integer.valueOf(jLabel_car_id.getText());
            // get the customer info
            int customer_id = Integer.valueOf(jLabel_customer_id.getText());
            // get the pickup info
            String pickup_city = jComboBox_Pickup_City.getSelectedItem().toString();
            String pickup_address = jComboBox_Pickup_Address.getSelectedItem().toString();

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String pickup_date = dateFormat.format(jDateChooser_Pickup_Date.getDate());
            Date pickup_date_ = dateFormat.parse(pickup_date);
            String pickup_time = timePicker_Pickup_Time.getText();

            // get the dropoff info
            String dropoff_city = jComboBox_Dropoff_City.getSelectedItem().toString();
            String dropoff_address = jComboBox_Dropoff_Address.getSelectedItem().toString();

            String dropoff_date = dateFormat.format(jDateChooser__Dropoff_Date.getDate());
            Date dropoff_date_ = dateFormat.parse(dropoff_date);
            String dropoff_time = timePicker_Dropoff_Time.getText();

            // get date difference in days
            long diff = dropoff_date_.getTime() - pickup_date_.getTime();
            //System.out.println("diff - " + diff);

            int diff_days = (int) (diff / 1000 / 60 / 60 / 24);
            //System.out.println("diff_days - " + diff_days);

            int price = Integer.valueOf(jLabel_car_price.getText());
            int total_price = diff_days * price;

            jLabel_price_text.setText("Total Price ("+String.valueOf(price)+" x "+String.valueOf(diff_days)+") :");
            jLabel_total_price.setText(String.valueOf(total_price));

            // check if the the dropoff date is before the pickup date
            if(dropoff_date_.before(pickup_date_))
            {
                JOptionPane.showMessageDialog(null, "The Drop Off Date Must Be After The Pickup Date", "Invalid Date", 2);
            }
            // check if the the dropoff date is equal to the pickup date
            else if(dropoff_date_.equals(pickup_date_))
            {
                // check if the the dropoff time is before the pickup time
                if(timePicker_Dropoff_Time.getTime().isBefore(timePicker_Pickup_Time.getTime()))
                {
                    JOptionPane.showMessageDialog(null, "The Drop Off Time Must Be After The Pickup Time", "Invalid Time", 2);
                }
                else
                {
                    // if it's the same day in different pickup and drop off time
                    // we will count it as 1H
                    total_price = 1 * price;
                    jLabel_price_text.setText("Total Price ("+String.valueOf(price)+" x "+String.valueOf(1)+") :");
                    jLabel_total_price.setText(String.valueOf(total_price));
                    booking.editBooking(id, car_id, customer_id, pickup_city, pickup_address, pickup_date, pickup_time, dropoff_city, dropoff_address, dropoff_date, dropoff_time, total_price);
                }
            }
            else
            {
                booking.editBooking(id, car_id, customer_id, pickup_city, pickup_address, pickup_date, pickup_time, dropoff_city, dropoff_address, dropoff_date, dropoff_time, total_price);
            }

        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null, "Enter Valid Data - Make Sure TO Enter All The Information", "Invalid Info", 2);
        }
        
        
    }//GEN-LAST:event_jButton_EditBooking_ActionPerformed

    private void jButton_BookingList_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_BookingList_ActionPerformed
        // display the booing list
        Form_BookingList bookingList = new Form_BookingList("edit");
        bookingList.setVisible(true);
    }//GEN-LAST:event_jButton_BookingList_ActionPerformed

    private void jButton_RemoveBooking_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_RemoveBooking_ActionPerformed
        // remove / cancel booking
        // booking id
        int id = Integer.valueOf(jLabel_booking_id.getText());
        
        int confirm = JOptionPane.showConfirmDialog(null, "Are You Sure You Want to Delete this Reservation?", "Confirm", JOptionPane.YES_NO_OPTION);
        
        if(confirm == JOptionPane.YES_OPTION)
        {
          booking.removeBooking(id);
        }
    }//GEN-LAST:event_jButton_RemoveBooking_ActionPerformed

    private void jButton_calculate_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_calculate_ActionPerformed
        try {
            // calculate the total price
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String pickup_date = dateFormat.format(jDateChooser_Pickup_Date.getDate());
            Date pickup_date_ = dateFormat.parse(pickup_date);
            //String pickup_time = timePicker_Pickup_Time.getText();

            // get the dropoff info
            String dropoff_date = dateFormat.format(jDateChooser__Dropoff_Date.getDate());
            Date dropoff_date_ = dateFormat.parse(dropoff_date);
            //String dropoff_time = timePicker_Dropoff_Time.getText();

            // get date difference in days
            long diff = dropoff_date_.getTime() - pickup_date_.getTime();
            //System.out.println("diff - " + diff);

            int diff_days = (int) (diff / 1000 / 60 / 60 / 24);
            //System.out.println("diff_days - " + diff_days);

            int price = Integer.valueOf(jLabel_car_price.getText());
            int total_price = diff_days * price;

            jLabel_price_text.setText("Total Price ("+String.valueOf(price)+" x "+String.valueOf(diff_days)+") :");
            jLabel_total_price.setText(String.valueOf(total_price));

            // check if the the dropoff date is before the pickup date
            if(dropoff_date_.before(pickup_date_))
            {
                JOptionPane.showMessageDialog(null, "The Drop Off Date Must Be After The Pickup Date", "Invalid Date", 2);
            }
            // check if the the dropoff date is equal to the pickup date
            else if(dropoff_date_.equals(pickup_date_))
            {
                // check if the the dropoff time is before the pickup time
                if(timePicker_Dropoff_Time.getTime().isBefore(timePicker_Pickup_Time.getTime()))
                {
                    JOptionPane.showMessageDialog(null, "The Drop Off Time Must Be After The Pickup Time", "Invalid Time", 2);
                }
                else
                {
                    // if it's the same day in different pickup and drop off time
                    // we will count it as 1H
                    total_price = 1 * price;
                    jLabel_price_text.setText("Total Price ("+String.valueOf(price)+" x "+String.valueOf(1)+") :");
                    jLabel_total_price.setText(String.valueOf(total_price));
                }
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "You Need To Select a Car and Pickup/Drop Date", "Invalid Info", 2);
            //Logger.getLogger(Form_BookCar.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_jButton_calculate_ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Form_Booking_Edit_Remove.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Form_Booking_Edit_Remove.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Form_Booking_Edit_Remove.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Form_Booking_Edit_Remove.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Form_Booking_Edit_Remove().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_BookingList_;
    private javax.swing.JButton jButton_EditBooking_;
    private javax.swing.JButton jButton_RemoveBooking_;
    private javax.swing.JButton jButton_calculate_;
    private javax.swing.JButton jButton_select_car_;
    private javax.swing.JButton jButton_select_customer_;
    public static javax.swing.JComboBox<String> jComboBox_Brands_;
    public static javax.swing.JComboBox<String> jComboBox_Dropoff_Address;
    public static javax.swing.JComboBox<String> jComboBox_Dropoff_City;
    public static javax.swing.JComboBox<String> jComboBox_Pickup_Address;
    public static javax.swing.JComboBox<String> jComboBox_Pickup_City;
    public static com.toedter.calendar.JDateChooser jDateChooser_Pickup_Date;
    public static com.toedter.calendar.JDateChooser jDateChooser__Dropoff_Date;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel_BookCar_logo;
    private static javax.swing.JLabel jLabel_booking_id;
    private static javax.swing.JLabel jLabel_brand_id;
    private static javax.swing.JLabel jLabel_car_id;
    private static javax.swing.JLabel jLabel_car_model;
    private static javax.swing.JLabel jLabel_car_price;
    private javax.swing.JLabel jLabel_close;
    private static javax.swing.JLabel jLabel_customer_id;
    private javax.swing.JLabel jLabel_dropoff;
    private javax.swing.JLabel jLabel_imagePath;
    private javax.swing.JLabel jLabel_pickup;
    private javax.swing.JLabel jLabel_price_text;
    private javax.swing.JLabel jLabel_price_text1;
    private javax.swing.JLabel jLabel_select_car;
    private javax.swing.JLabel jLabel_select_customer;
    private static javax.swing.JLabel jLabel_total_price;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel_dropoff;
    private javax.swing.JPanel jPanel_pickup;
    private javax.swing.JPanel jPanel_select_car;
    private javax.swing.JPanel jPanel_select_customer;
    private static javax.swing.JTextField jTextField_customer;
    public static com.github.lgooddatepicker.components.TimePicker timePicker_Dropoff_Time;
    public static com.github.lgooddatepicker.components.TimePicker timePicker_Pickup_Time;
    // End of variables declaration//GEN-END:variables
}
