/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author 1BestCsharp
 */
public class Customer {
    
    private int id;
    private String fullname;
    private String birthdate;
    private String phone;
    private String email;
    private String address;

    public Customer() {
    }

    public Customer(int id, String fullname, String birthdate, String phone, String email, String address) {
        this.id = id;
        this.fullname = fullname;
        this.birthdate = birthdate;
        this.phone = phone;
        this.email = email;
        this.address = address;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    
    
    
    
    
    // create a function to add a new customer
    public void addCustomer(String _fullname,String _birthdate,String _phone,String _email, String _address)
    {
        String insertQuery = "INSERT INTO `customers`(`fullname`, `birth_date`, `phone`, `email`, `address`) VALUES (?,?,?,?,?)";
        PreparedStatement ps;
        
        try {
            
            ps = DB.getConnection().prepareStatement(insertQuery);
            ps.setString(1, _fullname);
            ps.setString(2, _birthdate);
            ps.setString(3, _phone);
            ps.setString(4, _email);
            ps.setString(5, _address);
            
            if(ps.executeUpdate() != 0)
            {
                JOptionPane.showMessageDialog(null, "The New Customer Has Been Added", "Add Customer", 1);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Customer Not Added", "Add Customer", 2);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    // create a function to edit customer
    public void editCustomer(int _id, String _fullname,String _birthdate,String _phone,String _email, String _address)
    {
        String editQuery = "UPDATE `customers` SET `fullname`=?,`birth_date`=?,`phone`=?,`email`=?,`address`=? WHERE `id`=?";
        PreparedStatement ps;
        
        try {
            
            ps = DB.getConnection().prepareStatement(editQuery);
            ps.setString(1, _fullname);
            ps.setString(2, _birthdate);
            ps.setString(3, _phone);
            ps.setString(4, _email);
            ps.setString(5, _address);
            ps.setInt(6, _id);
            
            if(ps.executeUpdate() != 0)
            {
                JOptionPane.showMessageDialog(null, "The Customer Info Has Been Edited", "Edit Customer", 1);
                //System.out.println("Location Edited");
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Customer Info Not Edited", "Edit Customer", 2);
                //System.out.println("Location Not Edited");
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    // create a function to remove customer
    public void removeCustomer(int _id)
    {
        String editQuery = "DELETE FROM `customers` WHERE `id`=?";
        PreparedStatement ps;
        
        try {
            
            ps = DB.getConnection().prepareStatement(editQuery);
            ps.setInt(1, _id);
            
            if(ps.executeUpdate() != 0)
            {
                
                JOptionPane.showMessageDialog(null, "This Customer Has Been Deleted", "Delete Customer", 1);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Customer Not Deleted", "Delete Customer", 2);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    
    
    
    // create a function to return a resultset
    public ResultSet getData(String query)
    {
        PreparedStatement ps;
        ResultSet rs = null;
        
        try {
            
            ps = DB.getConnection().prepareStatement(query);
            rs = ps.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return rs;  
    }
    
    
    // create a function to get customer by id
    public Customer getCustomerById(int customer_id)
    {
        String query = "SELECT * FROM `customers` WHERE `id` = "+customer_id;
        ResultSet rs = getData(query);
        Customer customer = null;
        try {
            rs.next();
            customer = new Customer(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
        } catch (SQLException ex) {
            Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return customer;
    }
    
    
    // create a function to get all customers and return an arraylist
    public  ArrayList<Customer> customersList()
    {
        ArrayList<Customer> customersList = new ArrayList<>();
        
        ResultSet rs = getData("SELECT * FROM `customers`");
        
        try {
            while(rs.next())
            {
                Customer customer = new Customer(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
                customersList.add(customer);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return customersList;
        
    }
    
    
    
    
    
    
}
