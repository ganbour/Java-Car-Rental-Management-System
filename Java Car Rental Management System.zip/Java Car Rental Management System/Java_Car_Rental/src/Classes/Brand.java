/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import Classes.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author 1BestCsharp
 */
public class Brand {
    
    
    
    private int id;
    private String name;
    private byte[] logo;

    public Brand() {}
    
    public Brand(int _id, String _name, byte[] _logo) {
        this.id = _id;
        this.name = _name;
        this.logo = _logo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public byte[] getLogo() {
        return logo;
    }

    public void setLogo(byte[] logo) {
        this.logo = logo;
    }
    
    
    // create function to add a new brand
    public void addBrand(String _name, byte[] _logo)
    {
        String insertQuery = "INSERT INTO `brands`(`name`, `logo`) VALUES (?,?)";
        PreparedStatement ps;
        
        try {
            
            ps = DB.getConnection().prepareStatement(insertQuery);
            ps.setString(1, _name);
            ps.setBytes(2, _logo);
            
            if(ps.executeUpdate() != 0)
            {
                JOptionPane.showMessageDialog(null, "The New Brand Has Been Added", "Add Brand", 1);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Brand Not Added", "Add Brand", 2);
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Select a Smaller Size Image " +ex.getMessage(), "Add Brand", 2);
            //Logger.getLogger(Brand.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    
    
    // create function to edit brand
    public void editBrand(int _id, String _name, byte[] _logo)
    {
        String editQuery = "UPDATE `brands` SET `name`=?,`logo`=? WHERE `id` = ?";
        PreparedStatement ps;
        
        try {
            
            ps = DB.getConnection().prepareStatement(editQuery);
            ps.setString(1, _name);
            ps.setBytes(2, _logo);
            ps.setInt(3, _id);
            
            if(ps.executeUpdate() != 0)
            {
                JOptionPane.showMessageDialog(null, "The Brand Has Been Edited", "Edit Brand", 1);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Brand Not Edited", "Edit Brand", 2);
            }
            
        } 
        catch (Exception ex) 
                   {
                    JOptionPane.showMessageDialog(null, "Use a Smaller Size Image" , "Brand Logo", 2);
                   }
        
    }
    
    
    
    
    // create function to remove brand
    public void removeBrand(int _id)
    {
        String removeQuery = "DELETE FROM `brands` WHERE `id`=?";
        PreparedStatement ps;
        
        try {
            
            ps = DB.getConnection().prepareStatement(removeQuery);
            ps.setInt(1, _id);
            
            if(ps.executeUpdate() != 0)
            {
                
                JOptionPane.showMessageDialog(null, "This Brand Has Been Deleted", "Delete Brand", 1);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Brand Not Deleted", "Delete Brand", 2);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Brand.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    
    // create a function to return a resultset
    public ResultSet getData(String query)
    {
        PreparedStatement ps;
        ResultSet rs = null;
        
        try {
            
            ps = DB.getConnection().prepareStatement(query);
            rs = ps.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(Brand.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return rs;
        
    }
    
    
    // create a function to get all brands and return an arraylist
    public  ArrayList<Brand> brandsList()
    {
        ArrayList<Brand> brdList = new ArrayList<>();
        
        ResultSet rs = getData("SELECT * FROM `brands`");
        
        try {
            while(rs.next())
            {
               // System.out.println(rs.getInt(1));
               // System.out.println(rs.getString(2));
                Brand brand = new Brand(rs.getInt(1),rs.getString(2),rs.getBytes(3));
                brdList.add(brand);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Brand.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return brdList;
        
    }
    
    
    // create a unction to get brand by id
    public Brand getBrandById(int brand_id)
    {
        String query = "SELECT * FROM `brands` WHERE `id` = "+brand_id;
        ResultSet rs = getData(query);
        Brand brand = null;
        try {
            rs.next();
            brand = new Brand(rs.getInt(1), rs.getString(2), rs.getBytes(3));
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Edit Brand Error [ Select The Brand You Want to Edit ]" , "Edit Brand", 2);
            //Logger.getLogger(Brand.class.getName()).log(Level.SEVERE, null, ex);
        }
        return brand;
    }
    
    
    // create a function to poplate a hashmap with brands (id and name)
    public HashMap<Integer, String> brandsHashMap()
    {
        HashMap<Integer, String> brands_map = new HashMap<Integer, String>();
        
        ResultSet rs = getData("SELECT * FROM `brands`");
        
        try {
            while(rs.next())
            {
                brands_map.put(rs.getInt(1), rs.getString(2));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Brand.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return brands_map;
        
    }
    
}
