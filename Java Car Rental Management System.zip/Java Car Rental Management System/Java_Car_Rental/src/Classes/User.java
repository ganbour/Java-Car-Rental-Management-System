/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author 1BestCsharp
 */
public class User {
    
    private int id;
    private String fullname;
    private String username;
    private String password;
    private String user_type;
    private byte[] picture;
    private String phone;
    private String email;

    public User() {
    }

    public User(int id, String fullname, String username, String password, String user_type, byte[] picture, String phone, String email) {
        this.id = id;
        this.fullname = fullname;
        this.username = username;
        this.password = password;
        this.user_type = user_type;
        this.picture = picture;
        this.phone = phone;
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUser_type() {
        return user_type;
    }

    public void setUser_type(String user_type) {
        this.user_type = user_type;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public byte[] getPicture() {
        return picture;
    }

    public void setPicture(byte[] picture) {
        this.picture = picture;
    }
    
    
    
    
    
    // create a function to add a new user
    public void addUser(String _fullname, String _username, String _password, String _usertype, byte[] img, String _phone, String _email)
    {
        String insertQuery = "INSERT INTO `users`(`fullname`, `username`, `password`, `user_type`, `image`, `phone`, `email`) VALUES (?,?,?,?,?,?,?)";
        PreparedStatement ps;
        
        try {
            
            ps = DB.getConnection().prepareStatement(insertQuery);
            ps.setString(1, _fullname);
            ps.setString(2, _username);
            ps.setString(3, _password);
            ps.setString(4, _usertype);
            ps.setBytes(5, img);
            ps.setString(6, _phone);
            ps.setString(7, _email);
            
            if(ps.executeUpdate() != 0)
            {
                JOptionPane.showMessageDialog(null, "The New User Has Been Added", "Add User", 1);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "User Not Added", "Add User", 2);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    
    
    // create a function to edit user
    public void editUser(int _id, String _fullname, String _username, String _password, String _usertype, byte[] img, String _phone, String _email)
    {
        String editQuery = "UPDATE `users` SET `fullname`=?,`username`=?,`password`=?,`user_type`=?,`image`=?,`phone`=?,`email`=? WHERE `id`=?";
        PreparedStatement ps;
        
        try {
            
            ps = DB.getConnection().prepareStatement(editQuery);
            ps.setString(1, _fullname);
            ps.setString(2, _username);
            ps.setString(3, _password);
            ps.setString(4, _usertype);
            ps.setBytes(5, img);
            ps.setString(6, _phone);
            ps.setString(7, _email);
            ps.setInt(8, _id);
            
            if(ps.executeUpdate() != 0)
            {
                JOptionPane.showMessageDialog(null, "The User Info Has Been Edited", "Edit User", 1);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "User Info Not Edited", "Edit User", 2);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
    }
    
    // create a function to remove user
    public void removeUser(int _id)
    {
        String editQuery = "DELETE FROM `users` WHERE `id`=?";
        PreparedStatement ps;
        
        try {
            
            ps = DB.getConnection().prepareStatement(editQuery);
            ps.setInt(1, _id);
            
            if(ps.executeUpdate() != 0)
            {
                
                JOptionPane.showMessageDialog(null, "This User Has Been Deleted", "Delete User", 1);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "User Not Deleted", "Delete User", 2);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    
    // create a function to get user by id
    public User getUserById(int user_id)
    {
        String query = "SELECT * FROM `users` WHERE `id` = "+user_id;
        ResultSet rs = getData(query);
        User user = null;
        try {
            rs.next();
            user = new User(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getBytes(6),rs.getString(7),rs.getString(8));
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Enter a Valid User ID" , "Error", 2);
           //Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        return user;
    }
    
    
    // create a function to return a resultset
    public ResultSet getData(String query)
    {
        PreparedStatement ps;
        ResultSet rs = null;
        
        try {
            
            ps = DB.getConnection().prepareStatement(query);
            rs = ps.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return rs;  
    }
    
    
    // create a function to get all users and return an arraylist
    public  ArrayList<User> usersList()
    {
        ArrayList<User> users_List = new ArrayList<>();
        
        ResultSet rs = getData("SELECT * FROM `users`");
        
        try {
            while(rs.next())
            {
                User user = new User(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getBytes(6),rs.getString(7),rs.getString(8));
                users_List.add(user);
            }
        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return users_List;
        
    }
    
    
    
    
    
    
}
