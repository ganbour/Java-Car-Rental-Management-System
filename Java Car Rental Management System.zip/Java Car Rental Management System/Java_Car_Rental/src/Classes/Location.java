/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author 1BestCsharp
 */
public class Location {
    
    private int id;
    private String city;
    private String address;

    public Location() { }

    public Location(int _id, String _city, String _address) {
        this.id = _id;
        this.city = _city;
        this.address = _address;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    
    
    // create a function to add a new location
    public void addLocation(String _city, String _address)
    {
        String insertQuery = "INSERT INTO `locations`(`city`, `location`) VALUES (?,?)";
        PreparedStatement ps;
        
        try {
            
            ps = DB.getConnection().prepareStatement(insertQuery);
            ps.setString(1, _city);
            ps.setString(2, _address);
            
            if(ps.executeUpdate() != 0)
            {
                JOptionPane.showMessageDialog(null, "The New Location Has Been Added", "Add Location", 1);
                //System.out.println("Location Added");
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Location Not Added", "Add Location", 2);
                //System.out.println("Location Not Added");
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Location.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    // create a function to edit location
    public void editLocation(int _id, String _city, String _address)
    {
        String editQuery = "UPDATE `locations` SET `city`=?,`location`=? WHERE `id`=?";
        PreparedStatement ps;
        
        try {
            
            ps = DB.getConnection().prepareStatement(editQuery);
            ps.setString(1, _city);
            ps.setString(2, _address);
            ps.setInt(3, _id);
            
            if(ps.executeUpdate() != 0)
            {
                JOptionPane.showMessageDialog(null, "The Location Has Been Edited", "Edit Location", 1);
                //System.out.println("Location Edited");
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Location Not Edited", "Edit Location", 2);
                //System.out.println("Location Not Edited");
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Location.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    // create a function to remove location
    public void removeLocation(int _id)
    {
        String editQuery = "DELETE FROM `locations` WHERE `id`=?";
        PreparedStatement ps;
        
        try {
            
            ps = DB.getConnection().prepareStatement(editQuery);
            ps.setInt(1, _id);
            
            if(ps.executeUpdate() != 0)
            {
                
                JOptionPane.showMessageDialog(null, "This Location Has Been Deleted", "Delete Location", 1);
                //System.out.println("Locations Deleted");
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Location Not Deleted", "Delete Location", 2);
                //System.out.println("Locations Not Deleted");
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Location.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    
    
    
    // create a function to return a resultset
    public ResultSet getData(String query)
    {
        PreparedStatement ps;
        ResultSet rs = null;
        
        try {
            
            ps = DB.getConnection().prepareStatement(query);
            rs = ps.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(Location.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return rs;  
    }
    
    
    // create a function to get all locations and return an arraylist
    public  ArrayList<Location> locationsList()
    {
        ArrayList<Location> locList = new ArrayList<>();
        
        ResultSet rs = getData("SELECT * FROM `locations`");
        
        try {
            while(rs.next())
            {
                System.out.println(rs.getInt(1));
                System.out.println(rs.getString(2));
                Location location = new Location(rs.getInt(1),rs.getString(2),rs.getString(3));
                locList.add(location);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Location.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return locList;
        
    }
    
    
    
    // create a function to get all locations depending on the city param and return an arraylist
    public  ArrayList<Location> locationsListByCity(String city)
    {
        ArrayList<Location> locList = new ArrayList<>();
        ResultSet rs = getData("SELECT * FROM `locations` WHERE `city` = '"+ city+"'");
        
        try {
            while(rs.next())
            {
                Location location = new Location(rs.getInt(1),rs.getString(2),rs.getString(3));
                locList.add(location);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Location.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return locList;
        
    }
    
    
    
    
    
}
